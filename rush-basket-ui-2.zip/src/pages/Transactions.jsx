
const Transactions = () => {
  return (
    <div>
      <h1 className="text-4xl text-center p-5 font-semibold">Transections</h1>
    </div>
  );
}

export default Transactions