import React from 'react'

const PreviewCustomers = () => {
  return (
    <div>
      preview customer
    </div>
  )
}

export default PreviewCustomers
