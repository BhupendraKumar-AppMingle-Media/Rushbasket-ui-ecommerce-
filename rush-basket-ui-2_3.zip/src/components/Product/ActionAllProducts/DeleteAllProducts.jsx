import React from 'react'

const DeleteAllProducts = () => {
  return (
    <div>
         window.alert("All products have been deleted successfully")
    </div>
  )
}

export default DeleteAllProducts
