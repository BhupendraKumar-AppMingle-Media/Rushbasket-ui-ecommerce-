import React from 'react'

const EditCustomers = () => {
  return (
    <div>

        edit  customers page

      
    </div>
  )
}

export default EditCustomers
