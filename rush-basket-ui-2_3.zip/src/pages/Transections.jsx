import React from 'react'

const Transections = () => {
  return (
    <div>
      <h1 className="text-4xl text-center p-5 font-semibold">Transections</h1>
    </div>
  );
}

export default Transections