import React from 'react'

const HotOffer = () => {
  return (
    <div>
      <h1 className="text-4xl text-center p-5 font-semibold">HotOffer</h1>
    </div>
  );
}

export default HotOffer